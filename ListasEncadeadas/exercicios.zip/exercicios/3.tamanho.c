#include "listaEncadeada.h"

int main(void) {
  Lista I = no(3, no(1, no(5, NULL)));
  exibe2(I);
  printf(" = %d\n", tamanho(I));
  return 0;
}
